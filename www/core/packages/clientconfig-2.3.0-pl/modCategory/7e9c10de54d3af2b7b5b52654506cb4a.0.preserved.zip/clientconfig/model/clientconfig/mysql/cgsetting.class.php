<?php
require_once (dirname(dirname(__FILE__)) . '/cgsetting.class.php');
class cgSetting_mysql extends cgSetting {}