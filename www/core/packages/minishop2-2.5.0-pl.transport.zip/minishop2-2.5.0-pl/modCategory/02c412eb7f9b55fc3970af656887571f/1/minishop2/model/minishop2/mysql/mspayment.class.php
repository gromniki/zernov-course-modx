<?php
require_once (dirname(__DIR__) . '/mspayment.class.php');
class msPayment_mysql extends msPayment {}