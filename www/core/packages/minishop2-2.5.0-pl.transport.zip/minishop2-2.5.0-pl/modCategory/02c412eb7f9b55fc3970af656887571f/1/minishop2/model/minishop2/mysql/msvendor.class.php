<?php
require_once (dirname(__DIR__) . '/msvendor.class.php');
class msVendor_mysql extends msVendor {}