<?php
require_once (dirname(__DIR__) . '/msresourcefile.class.php');
class msResourceFile_mysql extends msResourceFile {}