<?php
require_once (dirname(__DIR__) . '/msresourcefiletag.class.php');
class msResourceFileTag_mysql extends msResourceFileTag {}