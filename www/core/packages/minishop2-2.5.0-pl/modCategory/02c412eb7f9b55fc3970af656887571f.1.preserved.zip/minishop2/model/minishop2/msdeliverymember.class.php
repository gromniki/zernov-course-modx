<?php
class msDeliveryMember extends xPDOObject {}